package oop.barcelo.trackify27.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import oop.barcelo.trackify27.db.MongoDBConnection;
import org.bson.Document;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.HexFormat;

public class RegistrationController {
    @FXML private TextField usernameField;
    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private PasswordField confirmPasswordField;
    @FXML private Button registerButton;

    @FXML
    private void onRegister() {
        String username = usernameField.getText().trim();
        String email = emailField.getText().trim();
        String password = passwordField.getText();
        String confirm = confirmPasswordField.getText();

        if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
            showAlert("All fields are required.");
            return;
        }
        if (!password.equals(confirm)) {
            showAlert("Passwords do not match.");
            return;
        }

        String hash = hashPassword(password);

        MongoDatabase db = MongoDBConnection.getDatabase();
        MongoCollection<Document> coll = db.getCollection("users");

        // check duplicate username/email
        if (coll.find(new Document("username", username)).first() != null) {
            showAlert("Username already exists.");
            return;
        }
        if (coll.find(new Document("email", email)).first() != null) {
            showAlert("Email already registered.");
            return;
        }

        Document doc = new Document();
        doc.append("username", username);
        doc.append("email", email);
        doc.append("password_hash", hash);
        doc.append("created_at", LocalDateTime.now().toString());
        doc.append("updated_at", LocalDateTime.now().toString());

        coll.insertOne(doc);
        showAlert("User registered successfully!");
        clearForm();
    }

    private void clearForm() {
        usernameField.clear();
        emailField.clear();
        passwordField.clear();
        confirmPasswordField.clear();
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Registration");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(password.getBytes());
            return HexFormat.of().formatHex(hashBytes);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
}

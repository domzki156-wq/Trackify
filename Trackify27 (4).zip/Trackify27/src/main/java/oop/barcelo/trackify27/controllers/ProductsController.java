package oop.barcelo.trackify27.controllers;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import oop.barcelo.trackify27.db.MongoDBConnection;
import oop.barcelo.trackify27.models.Product;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.time.LocalDateTime;
import java.util.Optional;

public class ProductsController {

    @FXML private TableView<Product> productTable;
    @FXML private TableColumn<Product, String> nameCol;
    @FXML private TableColumn<Product, String> categoryCol;
    @FXML private TableColumn<Product, Double> priceCol;
    @FXML private TableColumn<Product, Double> costCol;
    @FXML private TableColumn<Product, String> descriptionCol;

    @FXML private TextField nameField;
    @FXML private TextField categoryField;
    @FXML private TextField priceField;
    @FXML private TextField costField;
    @FXML private TextArea descriptionArea;

    private final ObservableList<Product> products = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        categoryCol.setCellValueFactory(new PropertyValueFactory<>("category"));
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        costCol.setCellValueFactory(new PropertyValueFactory<>("cost"));
        descriptionCol.setCellValueFactory(new PropertyValueFactory<>("description"));

        productTable.setItems(products);
        loadProducts();
    }

    private void loadProducts() {
        MongoDatabase db = MongoDBConnection.getDatabase();
        MongoCollection<Document> coll = db.getCollection("products");
        products.clear();
        for (Document d : coll.find()) {
            Product p = new Product(
                    d.getObjectId("_id").toHexString(),
                    d.getString("user_id"),
                    d.getString("name"),
                    d.getString("category"),
                    d.getString("description"),
                    d.getDouble("price"),
                    d.getDouble("cost")
            );
            products.add(p);
        }
    }

    @FXML
    private void onAdd() {
        try {
            String name = nameField.getText().trim();
            String category = categoryField.getText().trim();
            double price = Double.parseDouble(priceField.getText());
            double cost = Double.parseDouble(costField.getText());
            String desc = descriptionArea.getText().trim();

            if (name.isEmpty() || category.isEmpty()) {
                showAlert("Please fill in all required fields.");
                return;
            }

            MongoDatabase db = MongoDBConnection.getDatabase();
            MongoCollection<Document> coll = db.getCollection("products");

            Document doc = new Document()
                    .append("name", name)
                    .append("category", category)
                    .append("description", desc)
                    .append("price", price)
                    .append("cost", cost)
                    .append("created_at", LocalDateTime.now().toString())
                    .append("updated_at", LocalDateTime.now().toString());

            coll.insertOne(doc);
            showAlert("Product added successfully!");
            clearForm();
            loadProducts();
        } catch (Exception e) {
            showAlert("Invalid input. Please check numeric fields.");
        }
    }

    @FXML
    private void onUpdate() {
        Product sel = productTable.getSelectionModel().getSelectedItem();
        if (sel == null) {
            showAlert("Select a product to update.");
            return;
        }

        try {
            String name = nameField.getText().trim();
            String category = categoryField.getText().trim();
            double price = Double.parseDouble(priceField.getText());
            double cost = Double.parseDouble(costField.getText());
            String desc = descriptionArea.getText().trim();

            MongoDatabase db = MongoDBConnection.getDatabase();
            MongoCollection<Document> coll = db.getCollection("products");

            coll.updateOne(new Document("_id", new ObjectId(sel.getId())),
                    new Document("$set", new Document("name", name)
                            .append("category", category)
                            .append("description", desc)
                            .append("price", price)
                            .append("cost", cost)
                            .append("updated_at", LocalDateTime.now().toString()))
            );
            showAlert("Product updated!");
            clearForm();
            loadProducts();
        } catch (Exception e) {
            showAlert("Error updating product.");
        }
    }

    @FXML
    private void onDelete() {
        Product sel = productTable.getSelectionModel().getSelectedItem();
        if (sel == null) {
            showAlert("Select a product to delete.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION, "Delete selected product?", ButtonType.YES, ButtonType.NO);
        Optional<ButtonType> res = confirm.showAndWait();
        if (res.isPresent() && res.get() == ButtonType.YES) {
            MongoDatabase db = MongoDBConnection.getDatabase();
            MongoCollection<Document> coll = db.getCollection("products");
            coll.deleteOne(new Document("_id", new ObjectId(sel.getId())));
            loadProducts();
        }
    }

    @FXML
    private void onSelectRow() {
        Product sel = productTable.getSelectionModel().getSelectedItem();
        if (sel == null) return;
        nameField.setText(sel.getName());
        categoryField.setText(sel.getCategory());
        priceField.setText(String.valueOf(sel.getPrice()));
        costField.setText(String.valueOf(sel.getCost()));
        descriptionArea.setText(sel.getDescription());
    }

    @FXML
    private void clearForm() {
        nameField.clear();
        categoryField.clear();
        priceField.clear();
        costField.clear();
        descriptionArea.clear();
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Products");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}

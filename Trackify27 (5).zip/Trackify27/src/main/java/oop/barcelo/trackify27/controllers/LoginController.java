package oop.barcelo.trackify27.controllers;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import oop.barcelo.trackify27.HelloApplication;
import oop.barcelo.trackify27.db.MongoDBConnection;
import org.bson.Document;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;

import static com.mongodb.client.model.Filters.or;
import static com.mongodb.client.model.Filters.eq;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label messageLabel;

    // Called when user presses Login button
    @FXML
    private void onLoginPressed() {
        messageLabel.setText("");
        String userInput = usernameField.getText() == null ? "" : usernameField.getText().trim();
        String password = passwordField.getText() == null ? "" : passwordField.getText();

        if (userInput.isEmpty() || password.isEmpty()) {
            messageLabel.setText("Please enter username/email and password.");
            return;
        }

        String hashed = hashPassword(password);

        try {
            MongoDatabase db = MongoDBConnection.getDatabase(); // uses existing connection helper
            // try common collection names
            MongoCollection<Document> usersColl = db.getCollection("users");
            if (usersColl == null) {
                usersColl = db.getCollection("user");
            }

            // find by username OR email
            FindIterable<Document> found = usersColl.find(or(eq("username", userInput), eq("email", userInput)));
            Document userDoc = found.first();

            if (userDoc == null) {
                messageLabel.setText("No user found with that username/email.");
                return;
            }

            String storedHash = userDoc.getString("passwordHash");
            if (storedHash == null) storedHash = userDoc.getString("password"); // tolerate different field names

            if (storedHash != null && storedHash.equals(hashed)) {
                // success — store session and open dashboard
                UserController.setCurrentUser(userDoc);

                Stage stage = (Stage) usernameField.getScene().getWindow();
                // load dashboard (fall back to existing dashboard.fxml if present)
                try {
                    HelloApplication.openScene(stage, "/oop/barcelo/trackify27/fxml/dashboard.fxml", "Trackify - Dashboard");
                } catch (IOException e) {
                    // If dashboard missing or there's an error, load a simple placeholder
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/oop/barcelo/trackify27/fxml/dashboard.fxml"));
                    Parent root = loader.load(); // this will throw if dashboard.fxml missing, bubble up
                    Scene scene = new Scene(root);
                    stage.setScene(scene);
                }
            } else {
                messageLabel.setText("Incorrect password. Try again.");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            messageLabel.setText("Unable to login: " + ex.getMessage());
        }
    }

    @FXML
    private void onOpenRegistration() {
        try {
            Stage stage = (Stage) usernameField.getScene().getWindow();
            HelloApplication.openScene(stage, "/oop/barcelo/trackify27/fxml/registration.fxml", "Trackify - Register");
        } catch (IOException e) {
            e.printStackTrace();
            messageLabel.setText("Cannot open registration screen: " + e.getMessage());
        }
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(password.getBytes());
            return HexFormat.of().formatHex(digest);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
}

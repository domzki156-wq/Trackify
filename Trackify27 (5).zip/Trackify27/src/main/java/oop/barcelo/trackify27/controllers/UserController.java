package oop.barcelo.trackify27.controllers;

import org.bson.Document;

/**
 * Lightweight user/session holder.
 * Controllers can call UserController.getCurrentUser() to access logged-in user info.
 */
public class UserController {
    private static Document currentUser;

    public static void setCurrentUser(Document userDoc) {
        currentUser = userDoc;
    }

    public static Document getCurrentUser() {
        return currentUser;
    }

    public static void clear() {
        currentUser = null;
    }
}

plugins {
    java
    application
    id("org.openjfx.javafxplugin") version "0.0.13"
}

group = "oop.barcelo.trackify27"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

java {
    toolchain {
        // Use a stable LTS toolchain compatible with Gradle: 21
        languageVersion = JavaLanguageVersion.of(21)
    }
}

application {
    mainClass.set("oop.barcelo.trackify27.HelloApplication")
}

javafx {
    version = "21.0.6"
    modules = listOf("javafx.controls", "javafx.fxml")
}

dependencies {
    implementation(platform("org.mongodb:mongodb-driver-bom:5.6.1"))
    implementation("org.mongodb:mongodb-driver-sync")

    implementation("org.controlsfx:controlsfx:11.2.1")
    implementation("org.kordamp.bootstrapfx:bootstrapfx-core:0.4.0")

    testImplementation("org.junit.jupiter:junit-jupiter:5.12.1")
}

tasks.withType<Test> {
    useJUnitPlatform()
}

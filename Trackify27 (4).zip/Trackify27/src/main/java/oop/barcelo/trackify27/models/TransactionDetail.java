package oop.barcelo.trackify27.models;

public class TransactionDetail {
    private String id;
    private String transactionId;
    private String productId;
    private int quantity;
    private double priceAtSale;
    private double subtotal;

    public TransactionDetail() {}

    public TransactionDetail(String id, String transactionId, String productId, int quantity, double priceAtSale) {
        this.id = id;
        this.transactionId = transactionId;
        this.productId = productId;
        this.quantity = quantity;
        this.priceAtSale = priceAtSale;
        this.subtotal = priceAtSale * quantity;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getTransactionId() { return transactionId; }
    public void setTransactionId(String transactionId) { this.transactionId = transactionId; }

    public String getProductId() { return productId; }
    public void setProductId(String productId) { this.productId = productId; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public double getPriceAtSale() { return priceAtSale; }
    public void setPriceAtSale(double priceAtSale) { this.priceAtSale = priceAtSale; }

    public double getSubtotal() { return subtotal; }
    public void setSubtotal(double subtotal) { this.subtotal = subtotal; }
}

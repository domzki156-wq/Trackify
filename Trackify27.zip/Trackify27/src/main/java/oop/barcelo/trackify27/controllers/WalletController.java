package oop.barcelo.trackify27.controllers;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import oop.barcelo.trackify27.db.MongoDBConnection;
import oop.barcelo.trackify27.models.Wallet;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.time.LocalDateTime;
import java.util.Optional;

public class WalletController {

    @FXML private TableView<Wallet> walletTable;
    @FXML private TableColumn<Wallet, String> nameCol;
    @FXML private TableColumn<Wallet, String> currencyCol;
    @FXML private TableColumn<Wallet, Double> balanceCol;
    @FXML private TableColumn<Wallet, String> lastUpdatedCol;

    @FXML private TextField nameField;
    @FXML private TextField currencyField;
    @FXML private TextField amountField;

    private final ObservableList<Wallet> wallets = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        currencyCol.setCellValueFactory(new PropertyValueFactory<>("currency"));
        balanceCol.setCellValueFactory(new PropertyValueFactory<>("balance"));
        lastUpdatedCol.setCellValueFactory(new PropertyValueFactory<>("lastUpdated"));

        walletTable.setItems(wallets);
        loadWallets();
    }

    private void loadWallets() {
        MongoDatabase db = MongoDBConnection.getDatabase();
        MongoCollection<Document> coll = db.getCollection("wallets");
        wallets.clear();
        for (Document d : coll.find()) {
            Wallet w = new Wallet(
                    d.getObjectId("_id").toHexString(),
                    d.getString("user_id"),
                    d.getString("name"),
                    d.getDouble("balance"),
                    d.getString("currency")
            );
            wallets.add(w);
        }
    }

    @FXML
    private void onAddWallet() {
        String name = nameField.getText().trim();
        String currency = currencyField.getText().trim();

        if (name.isEmpty() || currency.isEmpty()) {
            showAlert("Please fill in wallet name and currency.");
            return;
        }

        MongoDatabase db = MongoDBConnection.getDatabase();
        MongoCollection<Document> coll = db.getCollection("wallets");

        Document doc = new Document()
                .append("name", name)
                .append("currency", currency)
                .append("balance", 0.0)
                .append("last_updated", LocalDateTime.now().toString());

        coll.insertOne(doc);
        showAlert("Wallet added successfully!");
        clearForm();
        loadWallets();
    }

    @FXML
    private void onDeposit() {
        Wallet sel = walletTable.getSelectionModel().getSelectedItem();
        if (sel == null) {
            showAlert("Select a wallet first.");
            return;
        }
        double amt = parseDoubleSafe(amountField.getText());
        if (amt <= 0) {
            showAlert("Enter a valid amount.");
            return;
        }

        MongoDatabase db = MongoDBConnection.getDatabase();
        MongoCollection<Document> coll = db.getCollection("wallets");

        double newBal = sel.getBalance() + amt;
        coll.updateOne(new Document("_id", new ObjectId(sel.getId())),
                new Document("$set", new Document("balance", newBal)
                        .append("last_updated", LocalDateTime.now().toString())));
        loadWallets();
    }

    @FXML
    private void onWithdraw() {
        Wallet sel = walletTable.getSelectionModel().getSelectedItem();
        if (sel == null) {
            showAlert("Select a wallet first.");
            return;
        }
        double amt = parseDoubleSafe(amountField.getText());
        if (amt <= 0) {
            showAlert("Enter a valid amount.");
            return;
        }
        if (amt > sel.getBalance()) {
            showAlert("Insufficient balance.");
            return;
        }

        MongoDatabase db = MongoDBConnection.getDatabase();
        MongoCollection<Document> coll = db.getCollection("wallets");

        double newBal = sel.getBalance() - amt;
        coll.updateOne(new Document("_id", new ObjectId(sel.getId())),
                new Document("$set", new Document("balance", newBal)
                        .append("last_updated", LocalDateTime.now().toString())));
        loadWallets();
    }

    private double parseDoubleSafe(String s) {
        try { return Double.parseDouble(s); } catch (Exception e) { return 0.0; }
    }

    private void clearForm() {
        nameField.clear();
        currencyField.clear();
        amountField.clear();
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Wallets");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}

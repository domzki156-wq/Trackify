package oop.barcelo.trackify27.models;

public class Transaction {
    private String id;
    private String date; // ISO date string
    private String customer;
    private String item;
    private String payment;
    private double revenue;
    private double cost;
    private double profit;
    private String notes;

    public Transaction() {}

    public Transaction(String id, String date, String customer, String item, String payment, double revenue, double cost, String notes) {
        this.id = id;
        this.date = date;
        this.customer = customer;
        this.item = item;
        this.payment = payment;
        this.revenue = revenue;
        this.cost = cost;
        this.profit = revenue - cost;
        this.notes = notes;
    }

    // getters / setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
    public String getCustomer() { return customer; }
    public void setCustomer(String customer) { this.customer = customer; }
    public String getItem() { return item; }
    public void setItem(String item) { this.item = item; }
    public String getPayment() { return payment; }
    public void setPayment(String payment) { this.payment = payment; }
    public double getRevenue() { return revenue; }
    public void setRevenue(double revenue) { this.revenue = revenue; this.profit = this.revenue - this.cost; }
    public double getCost() { return cost; }
    public void setCost(double cost) { this.cost = cost; this.profit = this.revenue - this.cost; }
    public double getProfit() { return profit; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}

package oop.barcelo.trackify27.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import oop.barcelo.trackify27.db.MongoDBConnection;
import oop.barcelo.trackify27.models.Transaction;
import org.bson.Document;
import org.bson.types.ObjectId;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import java.io.IOException;
import java.util.Optional;

public class DashboardController {

    @FXML private Label revenueLabel;
    @FXML private Label costLabel;
    @FXML private Label profitLabel;

    @FXML private TableView<Transaction> table;
    @FXML private TableColumn<Transaction, String> dateCol;
    @FXML private TableColumn<Transaction, String> customerCol;
    @FXML private TableColumn<Transaction, String> itemCol;
    @FXML private TableColumn<Transaction, String> paymentCol;
    @FXML private TableColumn<Transaction, Double> revenueCol;
    @FXML private TableColumn<Transaction, Double> costCol;
    @FXML private TableColumn<Transaction, Double> profitCol;
    @FXML private TableColumn<Transaction, String> notesCol;

    private ObservableList<Transaction> transactions = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));
        customerCol.setCellValueFactory(new PropertyValueFactory<>("customer"));
        itemCol.setCellValueFactory(new PropertyValueFactory<>("item"));
        paymentCol.setCellValueFactory(new PropertyValueFactory<>("payment"));
        revenueCol.setCellValueFactory(new PropertyValueFactory<>("revenue"));
        costCol.setCellValueFactory(new PropertyValueFactory<>("cost"));
        profitCol.setCellValueFactory(new PropertyValueFactory<>("profit"));
        notesCol.setCellValueFactory(new PropertyValueFactory<>("notes"));

        table.setItems(transactions);

        loadFromDatabase();
    }

    private void loadFromDatabase() {
        MongoDatabase db = MongoDBConnection.getDatabase();
        MongoCollection<Document> coll = db.getCollection("transactions");

        transactions.clear();

        double totalRevenue = 0, totalCost = 0, totalProfit = 0;
        for (Document d : coll.find()) {
            ObjectId oid = d.getObjectId("_id");
            String id = (oid != null) ? oid.toHexString() : "";
            String date = d.getString("date");
            String customer = d.getString("customer");
            String item = d.getString("item");
            String payment = d.getString("payment");

            Object revObj = d.get("revenue");
            double revenue = (revObj instanceof Number) ? ((Number) revObj).doubleValue() : 0.0;
            Object costObj = d.get("cost");
            double cost = (costObj instanceof Number) ? ((Number) costObj).doubleValue() : 0.0;

            String notes = d.getString("notes");

            Transaction t = new Transaction(id, date, customer, item, payment, revenue, cost, notes);
            transactions.add(t);
            totalRevenue += revenue;
            totalCost += cost;
            totalProfit += t.getProfit();
        }

        revenueLabel.setText(String.format("$%.2f", totalRevenue));
        costLabel.setText(String.format("$%.2f", totalCost));
        profitLabel.setText(String.format("$%.2f", totalProfit));
    }

    @FXML
    private void onRecordTransaction() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/oop/barcelo/trackify27/transaction_form.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Record Transaction");
            stage.setScene(new javafx.scene.Scene(root));

            TransactionFormController ctrl = loader.getController();
            ctrl.setOnSaved(() -> {
                loadFromDatabase();
                stage.close();
            });

            stage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void onDeleteSelected() {
        Transaction sel = table.getSelectionModel().getSelectedItem();
        if (sel == null) {
            Alert a = new Alert(Alert.AlertType.INFORMATION, "No transaction selected.", ButtonType.OK);
            a.showAndWait();
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION, "Delete selected transaction?", ButtonType.YES, ButtonType.NO);
        Optional<ButtonType> res = confirm.showAndWait();
        if (res.isPresent() && res.get() == ButtonType.YES) {
            MongoDatabase db = MongoDBConnection.getDatabase();
            MongoCollection<Document> coll = db.getCollection("transactions");
            try {
                coll.deleteOne(new Document("_id", new ObjectId(sel.getId())));
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            loadFromDatabase();

        }
    }
    @FXML
    private void onOpenRegistration() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/oop/barcelo/trackify27/registration.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Register User");
            stage.setScene(new javafx.scene.Scene(root));
            stage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    private void onOpenProducts() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/oop/barcelo/trackify27/products.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Manage Products");
            stage.setScene(new javafx.scene.Scene(root));
            stage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void onOpenWallets() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/oop/barcelo/trackify27/wallets.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Manage Wallets");
            stage.setScene(new javafx.scene.Scene(root));
            stage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
